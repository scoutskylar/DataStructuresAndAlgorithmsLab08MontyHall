﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiekhoffWalkerA3
{
    public partial class Form1 : Form
    {
        private int firstChoice = 0; //The first door the player chooses
        // Random numbers to select winning doors and show losing doors
        static Random randWin = new Random(), index = new Random();
        private int winDoor = randWin.Next(1, 4); 
        // List of all doors, the winner will be removed later.
        private IList<int> doors = new List<int>() { 1, 2, 3 };
        // The losing door that will be shown to the user, and its index
        // which will be determined later
        private int loserDoorToShow = 0, loserDoorToShowIndex = 999;
        private int winCount = 0, loseCount = 0; // win and lose counts
        //Booleans for the checkboxes (cheats and fun stuff)
        private bool hardMode = false, proGamer = false, reticulate = false;

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "Select a door by clicking on it.";
            winningDoorLabel.Text = "Winning Door: " + winDoor; //Cheat
        }

        // Door 1
        private void door1_Click(object sender, EventArgs e)
        {
            selected1.Visible = true;  // Marks the chosen door with a star
            firstChoice = 1;
            selection();
        }

        // Door 2
        private void door2_Click(object sender, EventArgs e)
        {
            selected2.Visible = true;
            firstChoice = 2;
            selection();
        }
        
 
        private void door3_Click(object sender, EventArgs e)
        {
            selected3.Visible = true;
            firstChoice = 3;
            selection();
        }

        //Runs after the player chooses their first door
        private void selection()
        {
            // Disables the buttons so you can't change your door after you
            // choose
            door1.Enabled = false;
            door2.Enabled = false;
            door3.Enabled = false;

            // Resets the list of doors (for replays)
            IList<int> doors = new List<int>() { 1, 2, 3 };

            // Removes the winning door from the list of doors
            doors.Remove(winDoor);

            // Prevents the program from showing you what's behind the door
            // you first chose
            if (firstChoice != winDoor)
                doors.Remove(firstChoice);

            // Selects an index from the list of losing doors
            // (index is random)
            loserDoorToShowIndex = index.Next(doors.Count());
            loserDoorToShow = doors[loserDoorToShowIndex];

            //Puts the winning image behind the winning door
            if (winDoor == 1)
                openDoor1.Image = Properties.Resources.winner;
            else if (winDoor == 2)
                openDoor2.Image = Properties.Resources.winner;
            else
                openDoor3.Image = Properties.Resources.winner;

            // Shows the user one losing door
            string num = loserDoorToShow.ToString();
            if (loserDoorToShow == 1)
                openDoor1.Visible = true;
            else if (loserDoorToShow == 2)
                openDoor2.Visible = true;
            else
                openDoor3.Visible = true;

            textBox1.Text = "You chose door number " + firstChoice + 
                ".\nDoor number " + num + " doesn't have the prize."
                + "\nDo you want to keep door " + firstChoice +
                " or exchange it?";

            // Shows the buttons
            exchangeButton.Enabled = true;
            exchangeButton.Visible = true;
            keepButton.Enabled = true;
            keepButton.Visible = true;
        }

        //If the player chooses to exchange their door
        private void exchangeButton_Click(object sender, EventArgs e)
        {
            // Removes the buttons
            exchangeButton.Enabled = false;
            exchangeButton.Visible = false;
            keepButton.Enabled = false;
            keepButton.Visible = false;

            // Determines whether the user won or lost
            if (firstChoice != winDoor)
            {
                textBox1.Text = "Congratulations! You won a Dodge Viper!";
                winCount++;
            }
            else
            {
                textBox1.Text = "Sorry, you lose! Try again!";
                loseCount++;
            }
            winLabel.Text = "Wins: " + winCount;
            loseLabel.Text = "Losses: " + loseCount;

            // Shows the user what was behind each door
            openDoor1.Visible = true;
            openDoor2.Visible = true;
            openDoor3.Visible = true;

            // Allows the user to restart the game
            retryButton.Enabled = true;
            retryButton.Visible = true;
        }
        
        // If the player chooses to keep their door
        private void keepButton_Click(object sender, EventArgs e)
        {
            // Removes the buttons
            exchangeButton.Enabled = false;
            exchangeButton.Visible = false;
            keepButton.Enabled = false;
            keepButton.Visible = false;

            // Determines whether the user won or lost
            if (firstChoice == winDoor)
            {
                textBox1.Text = "Congratulations! You won a Dodge Viper!";
                winCount++;
            }
            else
            {
                textBox1.Text = "Sorry, you lose! Try again!";
                loseCount++;
            }
            winLabel.Text = "Wins: " + winCount;
            loseLabel.Text = "Losses: " + loseCount;

            // Shows the user what was behind each door
            openDoor1.Visible = true;
            openDoor2.Visible = true;
            openDoor3.Visible = true;

            // Allows the user to restart the game
            retryButton.Enabled = true;
            retryButton.Visible = true;
        }

        // Shows a text box with the winning door
        private void reticulateSplinesButton_CheckedChanged(object sender, EventArgs e)
        {
            if (reticulate == false)
            {
                winningDoorLabel.Visible = true;
                reticulate = true;
            }
            else
            {
                winningDoorLabel.Visible = false;
                reticulate = false;
            }
        }

        // Turns the mouse cursor into crosshairs
        private void proGamerButton_CheckedChanged(object sender, EventArgs e)
        {
            
            if (proGamer == false)
            {
                this.Cursor = Cursors.Cross;
                proGamer = true;
            }
            else
            {
                this.Cursor = Cursors.Default;
                proGamer = false;
            }

        }
        
        // Makes the mouse cursor invisible
        private void hardModeButton_CheckStateChanged(object sender, EventArgs e)
        {
            if (hardMode == false)
            {
                Cursor.Hide();
                hardMode = true;
            }
            else
            {
                Cursor.Show();
                hardMode = false;
            }
        }


        // Dialog box with info on how to play the game
        private void helpButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The game begins with three doors.\n" +
                "Choose the door you believe to have a car behind it.\n" +
                "A losing door will then be shown and you will be given\n" +
                "the option to switch your door selection. The winning\n" +
                "door will then be shown.", "Instructions");
        }

        // Dialog box with information about the prizes
        private void infoButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THE PRIZE:\nA brand new Dodge Viper!\n\n" +
               "THE \"CONSOLATION PRIZES\":\n" +
               "A dastardly burglar steals your stuff!\n" +
               "Grizzly bear attack!\n" +
               "A knuckle supper from Chuck Norris!\n\n"+ "FUN FACT:\n" + 
               "Reticulate Splines doesn't mean anything. \n:^)");
        }

        //Restarts the game
        private void retryButton_Click(object sender, EventArgs e)
        {
            //Reset the game state
            firstChoice = 0;
            Random randWin = new Random(), index = new Random();
            winDoor = randWin.Next(1, 4);

            winningDoorLabel.Text = "Winning Door: " + winDoor;
            openDoor1.Image = Properties.Resources.loserdoor1;
            openDoor2.Image = Properties.Resources.loserdoor2;
            openDoor3.Image = Properties.Resources.loserdoor3;
            retryButton.Enabled = false;
            retryButton.Visible = false;
            openDoor1.Visible = false;
            openDoor2.Visible = false;
            openDoor3.Visible = false;
            selected1.Visible = false;
            selected2.Visible = false;
            selected3.Visible = false;
            door1.Enabled = true;
            door2.Enabled = true;
            door3.Enabled = true;

            textBox1.Text = "Select a door by clicking on it.";
        }
    }
}
