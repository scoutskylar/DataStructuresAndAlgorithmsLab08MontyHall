﻿/*
 * Ben Diekhoff, Broday Walker
 * CMPS 5113 Adv. Programming Language
 * Dr. Johnson
 * 11/21/19
 * This program runs the game called Let's Make a Deal. The user
 * is presented with three doors. One of the unselected doors will be 
 * revealed. The user will then have the option to change their original 
 * selection. The final result is then shown and the user is 
 * able to leave the game or play again if desired.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiekhoffWalkerA3
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            
        }
    }
}
