﻿namespace DiekhoffWalkerA3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param> 
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.exchangeButton = new System.Windows.Forms.Button();
            this.keepButton = new System.Windows.Forms.Button();
            this.retryButton = new System.Windows.Forms.Button();
            this.openDoor1 = new System.Windows.Forms.PictureBox();
            this.openDoor2 = new System.Windows.Forms.PictureBox();
            this.openDoor3 = new System.Windows.Forms.PictureBox();
            this.infoButton = new System.Windows.Forms.Button();
            this.selected3 = new System.Windows.Forms.PictureBox();
            this.helpButton = new System.Windows.Forms.Button();
            this.selected2 = new System.Windows.Forms.PictureBox();
            this.selected1 = new System.Windows.Forms.PictureBox();
            this.door3 = new System.Windows.Forms.Button();
            this.door2 = new System.Windows.Forms.Button();
            this.door1 = new System.Windows.Forms.Button();
            this.proGamerButton = new System.Windows.Forms.CheckBox();
            this.reticulateSplinesButton = new System.Windows.Forms.CheckBox();
            this.hardModeButton = new System.Windows.Forms.CheckBox();
            this.winLabel = new System.Windows.Forms.Label();
            this.loseLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.Label();
            this.winningDoorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.openDoor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDoor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDoor3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selected3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selected2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selected1)).BeginInit();
            this.SuspendLayout();
            // 
            // exchangeButton
            // 
            this.exchangeButton.Enabled = false;
            this.exchangeButton.Location = new System.Drawing.Point(251, 507);
            this.exchangeButton.Name = "exchangeButton";
            this.exchangeButton.Size = new System.Drawing.Size(158, 52);
            this.exchangeButton.TabIndex = 14;
            this.exchangeButton.Text = "Exchange";
            this.exchangeButton.UseVisualStyleBackColor = true;
            this.exchangeButton.Visible = false;
            this.exchangeButton.Click += new System.EventHandler(this.exchangeButton_Click);
            // 
            // keepButton
            // 
            this.keepButton.Enabled = false;
            this.keepButton.Location = new System.Drawing.Point(500, 507);
            this.keepButton.Name = "keepButton";
            this.keepButton.Size = new System.Drawing.Size(158, 52);
            this.keepButton.TabIndex = 15;
            this.keepButton.Text = "Keep";
            this.keepButton.UseVisualStyleBackColor = true;
            this.keepButton.Visible = false;
            this.keepButton.Click += new System.EventHandler(this.keepButton_Click);
            // 
            // retryButton
            // 
            this.retryButton.Enabled = false;
            this.retryButton.Image = global::DiekhoffWalkerA3.Properties.Resources.retry;
            this.retryButton.Location = new System.Drawing.Point(321, 559);
            this.retryButton.Name = "retryButton";
            this.retryButton.Size = new System.Drawing.Size(270, 90);
            this.retryButton.TabIndex = 16;
            this.retryButton.UseVisualStyleBackColor = true;
            this.retryButton.Visible = false;
            this.retryButton.Click += new System.EventHandler(this.retryButton_Click);
            // 
            // openDoor1
            // 
            this.openDoor1.Image = global::DiekhoffWalkerA3.Properties.Resources.loserdoor1;
            this.openDoor1.Location = new System.Drawing.Point(78, 21);
            this.openDoor1.Name = "openDoor1";
            this.openDoor1.Size = new System.Drawing.Size(266, 400);
            this.openDoor1.TabIndex = 12;
            this.openDoor1.TabStop = false;
            this.openDoor1.Visible = false;
            // 
            // openDoor2
            // 
            this.openDoor2.Image = global::DiekhoffWalkerA3.Properties.Resources.loserdoor2;
            this.openDoor2.Location = new System.Drawing.Point(344, 21);
            this.openDoor2.Name = "openDoor2";
            this.openDoor2.Size = new System.Drawing.Size(266, 400);
            this.openDoor2.TabIndex = 11;
            this.openDoor2.TabStop = false;
            this.openDoor2.Visible = false;
            // 
            // openDoor3
            // 
            this.openDoor3.Image = global::DiekhoffWalkerA3.Properties.Resources.loserdoor3;
            this.openDoor3.Location = new System.Drawing.Point(603, 21);
            this.openDoor3.Name = "openDoor3";
            this.openDoor3.Size = new System.Drawing.Size(266, 400);
            this.openDoor3.TabIndex = 10;
            this.openDoor3.TabStop = false;
            this.openDoor3.Visible = false;
            // 
            // infoButton
            // 
            this.infoButton.BackColor = System.Drawing.Color.Transparent;
            this.infoButton.Image = ((System.Drawing.Image)(resources.GetObject("infoButton.Image")));
            this.infoButton.Location = new System.Drawing.Point(12, 559);
            this.infoButton.Name = "infoButton";
            this.infoButton.Size = new System.Drawing.Size(90, 90);
            this.infoButton.TabIndex = 9;
            this.infoButton.UseVisualStyleBackColor = false;
            this.infoButton.Click += new System.EventHandler(this.infoButton_Click);
            // 
            // selected3
            // 
            this.selected3.BackColor = System.Drawing.Color.Transparent;
            this.selected3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("selected3.BackgroundImage")));
            this.selected3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.selected3.Image = ((System.Drawing.Image)(resources.GetObject("selected3.Image")));
            this.selected3.Location = new System.Drawing.Point(653, 70);
            this.selected3.Margin = new System.Windows.Forms.Padding(0);
            this.selected3.Name = "selected3";
            this.selected3.Size = new System.Drawing.Size(100, 100);
            this.selected3.TabIndex = 8;
            this.selected3.TabStop = false;
            this.selected3.Visible = false;
            // 
            // helpButton
            // 
            this.helpButton.Image = ((System.Drawing.Image)(resources.GetObject("helpButton.Image")));
            this.helpButton.Location = new System.Drawing.Point(782, 559);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(90, 90);
            this.helpButton.TabIndex = 7;
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // selected2
            // 
            this.selected2.BackColor = System.Drawing.Color.Transparent;
            this.selected2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("selected2.BackgroundImage")));
            this.selected2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.selected2.Image = ((System.Drawing.Image)(resources.GetObject("selected2.Image")));
            this.selected2.Location = new System.Drawing.Point(394, 70);
            this.selected2.Margin = new System.Windows.Forms.Padding(0);
            this.selected2.Name = "selected2";
            this.selected2.Size = new System.Drawing.Size(100, 100);
            this.selected2.TabIndex = 4;
            this.selected2.TabStop = false;
            this.selected2.Visible = false;
            // 
            // selected1
            // 
            this.selected1.BackColor = System.Drawing.Color.Transparent;
            this.selected1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("selected1.BackgroundImage")));
            this.selected1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.selected1.Image = ((System.Drawing.Image)(resources.GetObject("selected1.Image")));
            this.selected1.Location = new System.Drawing.Point(128, 70);
            this.selected1.Margin = new System.Windows.Forms.Padding(0);
            this.selected1.Name = "selected1";
            this.selected1.Size = new System.Drawing.Size(100, 100);
            this.selected1.TabIndex = 3;
            this.selected1.TabStop = false;
            this.selected1.Visible = false;
            // 
            // door3
            // 
            this.door3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("door3.BackgroundImage")));
            this.door3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.door3.Location = new System.Drawing.Point(603, 21);
            this.door3.Name = "door3";
            this.door3.Size = new System.Drawing.Size(200, 400);
            this.door3.TabIndex = 2;
            this.door3.Text = "3";
            this.door3.UseVisualStyleBackColor = true;
            this.door3.Click += new System.EventHandler(this.door3_Click);
            // 
            // door2
            // 
            this.door2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("door2.BackgroundImage")));
            this.door2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.door2.Location = new System.Drawing.Point(344, 21);
            this.door2.Name = "door2";
            this.door2.Size = new System.Drawing.Size(200, 400);
            this.door2.TabIndex = 1;
            this.door2.Text = "2";
            this.door2.UseVisualStyleBackColor = true;
            this.door2.Click += new System.EventHandler(this.door2_Click);
            // 
            // door1
            // 
            this.door1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("door1.BackgroundImage")));
            this.door1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.door1.Location = new System.Drawing.Point(78, 21);
            this.door1.Name = "door1";
            this.door1.Size = new System.Drawing.Size(200, 400);
            this.door1.TabIndex = 0;
            this.door1.Text = "1";
            this.door1.UseVisualStyleBackColor = true;
            this.door1.Click += new System.EventHandler(this.door1_Click);
            // 
            // proGamerButton
            // 
            this.proGamerButton.AutoSize = true;
            this.proGamerButton.Location = new System.Drawing.Point(128, 609);
            this.proGamerButton.Name = "proGamerButton";
            this.proGamerButton.Size = new System.Drawing.Size(106, 17);
            this.proGamerButton.TabIndex = 17;
            this.proGamerButton.Text = "Pro-Gamer Mode";
            this.proGamerButton.UseVisualStyleBackColor = true;
            this.proGamerButton.CheckedChanged += new System.EventHandler(this.proGamerButton_CheckedChanged);
            // 
            // reticulateSplinesButton
            // 
            this.reticulateSplinesButton.AutoSize = true;
            this.reticulateSplinesButton.Location = new System.Drawing.Point(128, 586);
            this.reticulateSplinesButton.Name = "reticulateSplinesButton";
            this.reticulateSplinesButton.Size = new System.Drawing.Size(111, 17);
            this.reticulateSplinesButton.TabIndex = 18;
            this.reticulateSplinesButton.Text = "Reticulate Splines";
            this.reticulateSplinesButton.UseVisualStyleBackColor = true;
            this.reticulateSplinesButton.CheckedChanged += new System.EventHandler(this.reticulateSplinesButton_CheckedChanged);
            // 
            // hardModeButton
            // 
            this.hardModeButton.AutoSize = true;
            this.hardModeButton.Location = new System.Drawing.Point(128, 632);
            this.hardModeButton.Name = "hardModeButton";
            this.hardModeButton.Size = new System.Drawing.Size(79, 17);
            this.hardModeButton.TabIndex = 19;
            this.hardModeButton.Text = "Hard Mode";
            this.hardModeButton.UseVisualStyleBackColor = true;
            this.hardModeButton.CheckStateChanged += new System.EventHandler(this.hardModeButton_CheckStateChanged);
            // 
            // winLabel
            // 
            this.winLabel.AutoSize = true;
            this.winLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winLabel.Location = new System.Drawing.Point(669, 586);
            this.winLabel.Name = "winLabel";
            this.winLabel.Size = new System.Drawing.Size(84, 25);
            this.winLabel.TabIndex = 20;
            this.winLabel.Text = "Wins: 0";
            // 
            // loseLabel
            // 
            this.loseLabel.AutoSize = true;
            this.loseLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loseLabel.Location = new System.Drawing.Point(648, 624);
            this.loseLabel.Name = "loseLabel";
            this.loseLabel.Size = new System.Drawing.Size(105, 25);
            this.loseLabel.TabIndex = 21;
            this.loseLabel.Text = "Losses: 0";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(144, 424);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(609, 80);
            this.textBox1.TabIndex = 22;
            this.textBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winningDoorLabel
            // 
            this.winningDoorLabel.AutoSize = true;
            this.winningDoorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winningDoorLabel.Location = new System.Drawing.Point(7, 518);
            this.winningDoorLabel.Name = "winningDoorLabel";
            this.winningDoorLabel.Size = new System.Drawing.Size(166, 25);
            this.winningDoorLabel.TabIndex = 23;
            this.winningDoorLabel.Text = "Winning Door: 0";
            this.winningDoorLabel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.winningDoorLabel);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.loseLabel);
            this.Controls.Add(this.winLabel);
            this.Controls.Add(this.hardModeButton);
            this.Controls.Add(this.reticulateSplinesButton);
            this.Controls.Add(this.proGamerButton);
            this.Controls.Add(this.retryButton);
            this.Controls.Add(this.keepButton);
            this.Controls.Add(this.exchangeButton);
            this.Controls.Add(this.openDoor1);
            this.Controls.Add(this.openDoor2);
            this.Controls.Add(this.openDoor3);
            this.Controls.Add(this.infoButton);
            this.Controls.Add(this.selected3);
            this.Controls.Add(this.helpButton);
            this.Controls.Add(this.selected2);
            this.Controls.Add(this.selected1);
            this.Controls.Add(this.door3);
            this.Controls.Add(this.door2);
            this.Controls.Add(this.door1);
            this.Name = "Form1";
            this.Text = "Let\'s Make a Deal";
            ((System.ComponentModel.ISupportInitialize)(this.openDoor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDoor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDoor3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selected3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selected2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selected1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button door1;
        private System.Windows.Forms.Button door2;
        private System.Windows.Forms.Button door3;
        private System.Windows.Forms.PictureBox selected1;
        private System.Windows.Forms.PictureBox selected2;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.PictureBox selected3;
        private System.Windows.Forms.Button infoButton;
        private System.Windows.Forms.PictureBox openDoor3;
        private System.Windows.Forms.PictureBox openDoor2;
        private System.Windows.Forms.PictureBox openDoor1;
        private System.Windows.Forms.Button exchangeButton;
        private System.Windows.Forms.Button keepButton;
        private System.Windows.Forms.Button retryButton;
        private System.Windows.Forms.CheckBox proGamerButton;
        private System.Windows.Forms.CheckBox reticulateSplinesButton;
        private System.Windows.Forms.CheckBox hardModeButton;
        private System.Windows.Forms.Label winLabel;
        private System.Windows.Forms.Label loseLabel;
        private System.Windows.Forms.Label textBox1;
        private System.Windows.Forms.Label winningDoorLabel;
    }
}

